import streamlit as st
import pandas as pd
import pickle

# Load the trained model
with open("random_forest_model.pkl", "rb") as file:
    model = pickle.load(file)

# Define user input function
def user_input_features():
    GenHlth = st.slider("General Health (1=Excellent, 5=Poor)", 1, 5, 3)
    HighBP = st.selectbox("High Blood Pressure", [0, 1])
    BMI = st.number_input("Body Mass Index (BMI)", min_value=10, max_value=50, value=25)
    HighChol = st.selectbox("High Cholesterol", [0, 1])
    Age = st.slider("Age", 18, 100, 50)
    DiffWalk = st.selectbox("Difficulty Walking", [0, 1])
    PhysHlth = st.slider("Physical Health Issues (Days in the past month)", 0, 30, 5)
    HeartDiseaseorAttack = st.selectbox("Heart Disease or Attack", [0, 1])
    
    data = {
        "GenHlth": GenHlth,
        "HighBP": HighBP,
        "BMI": BMI,
        "HighChol": HighChol,
        "Age": Age,
        "DiffWalk": DiffWalk,
        "PhysHlth": PhysHlth,
        "HeartDiseaseorAttack": HeartDiseaseorAttack,
    }
    return pd.DataFrame([data])

# Streamlit UI
st.title("Diabetes Prediction App")
st.write("Provide health details to predict the likelihood of diabetes.")

# Get user input
df_input = user_input_features()

# Predict
if st.button("Predict"):
    prediction = model.predict(df_input)[0]
    st.subheader("Prediction Result:")
    st.write("Diabetes: Yes" if prediction == 1 else "Diabetes: No")
